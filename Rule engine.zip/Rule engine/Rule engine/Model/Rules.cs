﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rule_engine.Model
{
    public class Rules
    {
        public static void CalculateRank(List<Team> teams)
        {
            int rank = 0;
            int previousposition = -1;
            int countOfTeamsWithSameRank = 0;
            teams = teams.OrderBy(i => i.Position).ToList();
            foreach (var f in teams)
            {
                if (f.Position != 0)
                {
                    if(f.Position == previousposition)
                    {
                        countOfTeamsWithSameRank += 1;
                        CalculatePoints(teams, previousposition);
                    }
                    if (f.Position != previousposition)
                    {
                        rank = rank + 1 + countOfTeamsWithSameRank;
                        countOfTeamsWithSameRank = 0;
                        if (previousposition != -1)
                        {
                            f.Points += f.Position;
                        }

                        
                    }
                    f.Rank = rank;
                }
                previousposition = f.Position;
                Console.WriteLine(f.Name + " has rank – " + f.Rank  + " – "+ f.Points);
            }
            Console.WriteLine();
        }

        public static void CalculatePoints(List<Team> teams, int index)
        {
            int previousSamePoints = 0;
            
            //if(index == - 1)
            //{
            //    index = 0;
            //}

            if (index < teams.Count)
            {
                index -= 1;
                teams[index].Points += ((teams[index].Position + 1) + teams[index].Position) * 0.5;
                
            }

        }

    }
}
